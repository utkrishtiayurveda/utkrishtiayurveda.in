UTKRISHTI AYURVEDA — AUTOMATIC SITEMAP PACKAGE

UPLOAD THESE FILES TO THE REPOSITORY ROOT:
- sitemap.xml
- robots.txt
- scripts/generate-sitemap.mjs
- .github/workflows/generate-sitemap.yml

HOW IT WORKS
1. Every push to main runs the GitHub Action.
2. The generator scans all .html files automatically.
3. Any page containing a robots/googlebot meta tag with "noindex" is excluded.
4. If an indexable page has a canonical URL, that canonical URL is used.
5. Otherwise the URL is generated from the HTML path.
6. Each URL receives a lastmod value based on that file's latest Git commit.
7. Duplicate canonical URLs are removed.
8. If sitemap.xml changes, GitHub Actions commits the new sitemap automatically.
9. The auto-generated sitemap commit does not create an infinite workflow loop because sitemap.xml itself is ignored as a workflow trigger.

BLOG BEHAVIOUR
- New /blog/*.html articles are automatically discovered.
- You do NOT need to manually edit sitemap.xml when a blog is added.
- blog-data.js still controls your blog listing/pagination/internal links.
- The sitemap generator independently scans the real HTML article files, which prevents a blog-data entry pointing to a missing page from being submitted to search engines.

NOINDEX PAGES
Pages such as booking/tracking pages stay out of the sitemap as long as their HTML contains:
<meta name="robots" content="noindex,follow">

ROBOTS.TXT
robots.txt points search engines to:
https://utkrishtiayurveda.in/sitemap.xml

AFTER UPLOAD
Open GitHub → Actions → "Generate Sitemap".
It should also run automatically on the next push to main.
